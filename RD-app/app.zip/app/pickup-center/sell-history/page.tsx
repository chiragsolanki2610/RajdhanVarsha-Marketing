'use client';

import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import {
  RefreshCw,
  Loader2,
  Search,
  PackageSearch,
  ChevronDown,
  FileText,
  ShoppingBag,
  IndianRupee,
  Boxes,
  Receipt,
} from 'lucide-react';
import PickupCenterSidebar from '@/components/pickup_centersidebar';
import PickupCenterTopbar from '@/components/pickup_centertopbar';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'https://localhost:56187';

type Source = 'Counter Sale' | 'Plan Activation' | 'Online Order';

interface SaleItem {
  productName: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
}

interface Sale {
  orderId: number;
  orderNo: string;
  source: Source;
  planType: string;
  customerId: string;
  customerName: string;
  customerPhone?: string | null;
  paymentMethod?: string | null;
  items: SaleItem[];
  totalItems: number;
  totalAmount: number;
  totalBv: number;
  soldAt: string;
  receiptAvailable: boolean;
}

interface Summary {
  totalSales: number;
  totalItemsSold: number;
  totalAmount: number;
  totalBv: number;
}

const sourceStyles: Record<Source, string> = {
  'Counter Sale': 'bg-blue-50 text-blue-700 border-blue-200',
  'Plan Activation': 'bg-purple-50 text-purple-700 border-purple-200',
  'Online Order': 'bg-amber-50 text-amber-700 border-amber-200',
};

const inr = (n: number) => `₹${(n ?? 0).toLocaleString('en-IN')}`;

const formatDate = (iso: string) =>
  new Date(iso).toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

// yyyy-MM-dd in the user's local timezone (used for the date-range filter)
const localDay = (iso: string) => {
  const d = new Date(iso);
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
};

export default function SellHistoryPage() {
  const router = useRouter();

  const [sales, setSales] = useState<Sale[]>([]);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [operatorName, setOperatorName] = useState('');

  const [search, setSearch] = useState('');
  const [sourceFilter, setSourceFilter] = useState<'All' | Source>('All');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [downloadingId, setDownloadingId] = useState<number | null>(null);

  const getToken = () =>
    typeof window === 'undefined' ? null : localStorage.getItem('pucToken');

  useEffect(() => {
    try {
      const raw = localStorage.getItem('pucInfo');
      if (raw) setOperatorName(JSON.parse(raw)?.fullName || '');
    } catch (e) {
      console.error('Failed parsing pucInfo from localStorage:', e);
    }
  }, []);

  const logoutToLogin = useCallback(() => {
    localStorage.removeItem('pucToken');
    localStorage.removeItem('pucInfo');
    router.replace('/pickup-center');
  }, [router]);

  const fetchHistory = useCallback(async () => {
    const token = getToken();
    if (!token) {
      router.replace('/pickup-center');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch(`${API_BASE}/api/PickupCenter/sell-history`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.status === 401) {
        logoutToLogin();
        return;
      }
      if (!res.ok) throw new Error(`Failed to load sell history (status ${res.status})`);

      const data = await res.json();
      setSales(Array.isArray(data?.sales) ? data.sales : []);
      setSummary(data?.summary ?? null);
    } catch (err: any) {
      console.error('Error fetching sell history:', err);
      setError(err?.message || 'Something went wrong while loading sell history.');
    } finally {
      setIsLoading(false);
    }
  }, [router, logoutToLogin]);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return sales.filter((s) => {
      if (sourceFilter !== 'All' && s.source !== sourceFilter) return false;

      const day = localDay(s.soldAt);
      if (fromDate && day < fromDate) return false;
      if (toDate && day > toDate) return false;

      if (!q) return true;
      return (
        s.orderNo.toLowerCase().includes(q) ||
        s.customerName.toLowerCase().includes(q) ||
        s.customerId.toLowerCase().includes(q) ||
        (s.customerPhone ?? '').toLowerCase().includes(q) ||
        s.items.some((i) => i.productName.toLowerCase().includes(q))
      );
    });
  }, [sales, search, sourceFilter, fromDate, toDate]);

  // Totals for whatever is currently filtered on screen
  const shown = useMemo(
    () => ({
      sales: filtered.length,
      items: filtered.reduce((a, s) => a + s.totalItems, 0),
      amount: filtered.reduce((a, s) => a + s.totalAmount, 0),
      bv: filtered.reduce((a, s) => a + s.totalBv, 0),
    }),
    [filtered]
  );

  const isFiltered = !!(search || fromDate || toDate || sourceFilter !== 'All');

  const downloadReceipt = async (sale: Sale) => {
    const token = getToken();
    if (!token) {
      router.replace('/pickup-center');
      return;
    }
    setDownloadingId(sale.orderId);
    try {
      const res = await fetch(
        `${API_BASE}/api/PickupCenter/sell-history/${sale.orderId}/receipt`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      if (!res.ok) throw new Error('Receipt is not available for this sale.');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      setTimeout(() => URL.revokeObjectURL(url), 60_000);
    } catch (e: any) {
      alert(e?.message || 'Could not download receipt.');
    } finally {
      setDownloadingId(null);
    }
  };

  const statCards = [
    { label: 'Total Sales', value: String(shown.sales), icon: ShoppingBag },
    { label: 'Items Sold', value: shown.items.toLocaleString('en-IN'), icon: Boxes },
    { label: 'Sales Amount', value: inr(shown.amount), icon: IndianRupee },
    { label: 'Total BV', value: shown.bv.toLocaleString('en-IN'), icon: Receipt },
  ];

  return (
    <div className="flex min-h-screen bg-slate-50">
      <PickupCenterSidebar />

      <div className="flex-1 flex flex-col min-w-0 pb-16 md:pb-0">
        <PickupCenterTopbar title="Sell History" operatorName={operatorName} />

        <main className="w-full max-w-6xl mx-auto px-3 sm:px-4 py-5 sm:py-6 overflow-x-hidden">
          {/* Summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
            {statCards.map(({ label, value, icon: Icon }) => (
              <div key={label} className="bg-white border border-gray-100 rounded-2xl shadow-sm p-4">
                <div className="flex items-center gap-2 text-gray-400 text-[11px] uppercase tracking-wide font-semibold">
                  <Icon size={14} />
                  {label}
                </div>
                <p className="mt-2 text-xl font-bold text-[#3B5998]">{value}</p>
              </div>
            ))}
          </div>
          {isFiltered && summary && (
            <p className="-mt-3 mb-5 text-xs text-gray-400">
              Showing filtered results · all-time: {summary.totalSales} sales, {summary.totalItemsSold} items,{' '}
              {inr(summary.totalAmount)}
            </p>
          )}

          {/* Filters */}
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-3 sm:p-4 mb-6 space-y-3 md:space-y-0 md:flex md:flex-wrap md:items-end md:gap-3">
            <div className="relative md:flex-1 md:min-w-[240px]">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search customer, product, order no."
                className="w-full pl-9 pr-3 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 border border-gray-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-[#3B5998]/30"
              />
            </div>

            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value as 'All' | Source)}
              className="w-full md:w-auto text-sm text-gray-800 border border-gray-200 rounded-xl px-3 py-2.5 bg-white focus:outline-none focus:ring-2 focus:ring-[#3B5998]/30"
            >
              <option value="All">All sources</option>
              <option value="Counter Sale">Counter Sale</option>
              <option value="Plan Activation">Plan Activation</option>
              <option value="Online Order">Online Order</option>
            </select>

            <div className="grid grid-cols-2 gap-3 md:flex md:gap-2 md:items-end">
              <label className="block min-w-0">
                <span className="block text-[11px] font-semibold uppercase tracking-wide text-gray-400 mb-1">From</span>
                <input
                  type="date"
                  value={fromDate}
                  max={toDate || undefined}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full min-w-0 text-sm text-gray-800 border border-gray-200 rounded-xl px-2.5 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#3B5998]/30"
                />
              </label>
              <label className="block min-w-0">
                <span className="block text-[11px] font-semibold uppercase tracking-wide text-gray-400 mb-1">To</span>
                <input
                  type="date"
                  value={toDate}
                  min={fromDate || undefined}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full min-w-0 text-sm text-gray-800 border border-gray-200 rounded-xl px-2.5 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-[#3B5998]/30"
                />
              </label>
            </div>

            <div className="flex items-center gap-3 md:ml-auto">
              {isFiltered && (
                <button
                  onClick={() => {
                    setSearch('');
                    setFromDate('');
                    setToDate('');
                    setSourceFilter('All');
                  }}
                  className="flex-1 md:flex-none text-sm font-semibold text-gray-500 hover:text-[#3B5998] border border-gray-200 rounded-xl px-3 py-2.5"
                >
                  Clear
                </button>
              )}
              <button
                onClick={fetchHistory}
                disabled={isLoading}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 text-sm font-medium text-gray-600 hover:text-[#3B5998] bg-white border border-gray-200 rounded-xl px-3 py-2.5 transition-colors disabled:opacity-50"
              >
                <RefreshCw size={15} className={isLoading ? 'animate-spin' : ''} />
                Refresh
              </button>
            </div>
          </div>

          {error && (
            <div className="mb-6 rounded-xl border border-red-200 bg-red-50 text-red-700 text-sm px-4 py-3">
              {error}
            </div>
          )}

          {isLoading && (
            <div className="flex flex-col items-center justify-center py-24 text-gray-400">
              <Loader2 size={28} className="animate-spin mb-3" />
              <p className="text-sm">Loading sell history…</p>
            </div>
          )}

          {!isLoading && !error && filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-24 text-gray-400 bg-white rounded-2xl border border-gray-100 shadow-sm">
              <PackageSearch size={36} className="mb-3" />
              <p className="text-sm font-medium">
                {sales.length === 0 ? 'No sales yet' : 'No sales match your filters'}
              </p>
            </div>
          )}

          {!isLoading && !error && filtered.length > 0 && (
            <div className="space-y-3">
              {filtered.map((s) => {
                const open = expandedId === s.orderId;
                return (
                  <div
                    key={s.orderId}
                    className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden"
                  >
                    <button
                      type="button"
                      onClick={() => setExpandedId(open ? null : s.orderId)}
                      className="w-full text-left px-4 py-4 hover:bg-gray-50/60 transition-colors md:flex md:items-center md:gap-6"
                    >
                      {/* Row 1 (mobile): order no + date  |  amount */}
                      <div className="flex items-start justify-between gap-3 md:block md:w-[150px] md:shrink-0">
                        <div className="min-w-0">
                          <p className="text-xs font-mono text-gray-400">#{s.orderNo}</p>
                          <p className="text-xs text-gray-500">{formatDate(s.soldAt)}</p>
                        </div>
                        <div className="text-right md:hidden shrink-0">
                          <p className="font-bold text-gray-800 leading-tight">{inr(s.totalAmount)}</p>
                          <p className="text-xs text-gray-400">{s.totalBv} BV</p>
                        </div>
                      </div>

                      {/* Row 2 (mobile): customer */}
                      <div className="mt-2 md:mt-0 md:flex-1 min-w-0">
                        <p className="font-semibold text-gray-800 break-words">{s.customerName}</p>
                        <p className="text-xs text-gray-400 break-all">
                          {s.customerId}
                          {s.customerPhone ? ` · ${s.customerPhone}` : ''}
                        </p>
                      </div>

                      {/* Row 3 (mobile): source badge · item count · chevron */}
                      <div className="mt-3 md:mt-0 flex items-center gap-3 md:gap-6">
                        <span
                          className={`text-[10px] font-semibold uppercase tracking-wide border rounded-full px-2.5 py-1 whitespace-nowrap ${sourceStyles[s.source]}`}
                        >
                          {s.source}
                        </span>

                        <span className="text-sm text-gray-600 whitespace-nowrap">
                          {s.totalItems} {s.totalItems === 1 ? 'item' : 'items'}
                        </span>

                        <div className="hidden md:block text-right min-w-[90px]">
                          <p className="font-bold text-gray-800">{inr(s.totalAmount)}</p>
                          <p className="text-xs text-gray-400">{s.totalBv} BV</p>
                        </div>

                        <ChevronDown
                          size={18}
                          className={`ml-auto md:ml-0 shrink-0 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`}
                        />
                      </div>
                    </button>

                    {open && (
                      <div className="border-t border-gray-100 bg-gray-50/50 px-4 py-4">
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs sm:text-sm">
                            <thead>
                              <tr className="text-[11px] uppercase tracking-wide text-gray-400">
                                <th className="text-left font-semibold py-2">Product</th>
                                <th className="text-right font-semibold py-2">Qty</th>
                                <th className="text-right font-semibold py-2">Price</th>
                                <th className="text-right font-semibold py-2">Total</th>
                              </tr>
                            </thead>
                            <tbody>
                              {s.items.length === 0 && (
                                <tr>
                                  <td colSpan={4} className="py-3 text-gray-400 text-center">
                                    Item details not available for this sale.
                                  </td>
                                </tr>
                              )}
                              {s.items.map((i, idx) => (
                                <tr key={idx} className="border-t border-gray-100">
                                  <td className="py-2 pr-2 text-gray-700 break-words">{i.productName}</td>
                                  <td className="py-2 text-right text-gray-700">{i.quantity}</td>
                                  <td className="py-2 text-right text-gray-500">{inr(i.unitPrice)}</td>
                                  <td className="py-2 text-right font-semibold text-gray-800">
                                    {inr(i.lineTotal)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>

                        <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-xs text-gray-500">
                          <span>
                            {s.source === 'Plan Activation' && `Plan: ${s.planType} · `}
                            {s.paymentMethod && `Payment: ${s.paymentMethod.toUpperCase()}`}
                          </span>

                          {s.receiptAvailable && (
                            <button
                              onClick={() => downloadReceipt(s)}
                              disabled={downloadingId === s.orderId}
                              className="inline-flex items-center gap-1.5 font-semibold text-[#3B5998] border border-[#3B5998]/20 hover:bg-[#3B5998]/5 rounded-lg px-3 py-1.5 transition-colors disabled:opacity-50"
                            >
                              {downloadingId === s.orderId ? (
                                <Loader2 size={13} className="animate-spin" />
                              ) : (
                                <FileText size={13} />
                              )}
                              Receipt
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}